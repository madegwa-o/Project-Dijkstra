package com.example.Htmx_Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmxSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmxSpringApplication.class, args);
	}

}

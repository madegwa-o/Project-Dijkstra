package com.example.Dijkstra_gradle_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DijkstraGradleBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DijkstraGradleBackendApplication.class, args);
	}

}

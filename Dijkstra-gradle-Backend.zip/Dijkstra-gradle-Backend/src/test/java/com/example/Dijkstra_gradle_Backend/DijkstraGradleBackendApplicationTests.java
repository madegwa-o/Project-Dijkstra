package com.example.Dijkstra_gradle_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DijkstraGradleBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
